Taillard instances for the permutation flow shop scheduling problem.

File format (one instance per file):
  line 1     : n m              (number of jobs, number of machines)
  lines 2..m+1: n integers each  (row i = processing times of jobs 1..n on machine i)

Best-known bounds: pfsp-bounds.csv on the website.
